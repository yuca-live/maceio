# MACEIÓ
Package to insert JSON data in SQL database.

## Features
- Create a new table based a json structure
- Insert a new line or update in table;
